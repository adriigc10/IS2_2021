package es.unican.is2.practica4;

/**
 * Metodo de excepcion DatoIncorrectoException
 * @author Borja Cuevas Cuesta y Adrian Garcia Cubas
 *
 */
@SuppressWarnings("serial")
public class DatoIncorrectoException extends RuntimeException{}
