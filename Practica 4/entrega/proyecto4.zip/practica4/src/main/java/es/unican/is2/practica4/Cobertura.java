package es.unican.is2.practica4;

/**
 * Enumeracion de los tipos de cobertura
 * @author Borja Cuevas Cuesta y Adrian Garcia Cubas
 *
 */
public enum Cobertura {
	TERCEROS, TODORIESGO, TERCEROSLUNAS
}
